package com.example.jazik.thebeach;

import android.renderscript.Element;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.FormElement;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


import java.io.IOException;
//import java.sql.Connection;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Document doc = Jsoup.connect("http://www.thebeach.se/spela_beachvolley/guldkort/bokningslaget-just-nu/").get();
                    String title = doc.toString();
                    FormElement f = (FormElement) doc.select("form#sc_book_view_form").first();
                    Elements elements = f.elements();
                    List<Connection.KeyVal> values = f.formData();
                    Log.d("erik", f.formData().toString());

                    Log.d("formdata", f.formData().get(0).toString());
                    Elements elementobj = doc.select("table").select("tbody");
                    Attributes a = f.attributes();
//                    values.set(0, "2016-01-26");
                    OnGotTime(doc.getElementsByClass("sc_slot_box").not(".booked"));
                    Connection.KeyVal k = f.formData().get(0);
                    k.value("2016-01-28");
                    f.formData().set(0, k);
                    Document doc2 = Jsoup.connect("http://www.thebeach.se/spela_beachvolley/guldkort/bokningslaget-just-nu/").data("date", "2016-01-28").post();
                    OnGotTime(doc2.getElementsByClass("sc_slot_box").not(".booked"));

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    void OnGotTime(Elements elements)
    {
        int count = 0;
//        Log.d("erik", elements.toString());
        for (org.jsoup.nodes.Element e : elements)
        {
            if (e.text().startsWith("17"))
            {
//                Log.d("element", e.text());
                ++count;
            }
        }
        String c = "count " + count;
        Log.d("Count", c);
//        TextView myText = (TextView) findViewById(R.id.grogg);
//        myText.setText(elements.toString());
    }
}
